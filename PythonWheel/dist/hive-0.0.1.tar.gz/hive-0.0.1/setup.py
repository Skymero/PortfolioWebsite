import setuptools

setuptools.setup(
    name="hive",
    version="0.0.1",
    #author="Ron LEsteve",
    #author_email="ronlesteve@ronlesteve.com",
    #description="Package to create Hive",
    #long_description_content_type="text/markdown",
    packages=setuptools.find_packages(),
    #classifiers=[
    #    "Programming Language :: Python :: 3",
    #    "License :: OSI Approved :: MIT License",
    #    "Operating System :: OS Independent",
    #],
    python_requires='>=3.7',
)
setuptools.setup(
    name="selenium",
    version="4.0.0",
    packages=setuptools.find_packages(),
    python_requires='>=4.0',
)
setuptools.setup(
    name="Faker",
    version="4.1.1",
    #author="Ron LEsteve",
    #author_email="ronlesteve@ronlesteve.com",
    #description="Package to create Hive",
    #long_description_content_type="text/markdown",
    packages=setuptools.find_packages(),
    #classifiers=[
    #    "Programming Language :: Python :: 3",
    #    "License :: OSI Approved :: MIT License",
    #    "Operating System :: OS Independent",
    #],
    python_requires='>=4.1.1',
)